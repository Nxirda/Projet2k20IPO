package util;

public enum Direction {
	up, down, right, left
}
