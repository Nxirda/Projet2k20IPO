package frog;

import gameCommons.Game;
import gameCommons.IFrog;

public class Frog implements IFrog {
	
	private Game game;


}
